package com.example.e_learningcuea;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {
//declare view item
    public WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        //paste the url
        webView.loadUrl("https://elearning.cuea.edu");
        webView.setWebViewClient(new WebViewClient());
    }
    //code to call the button
    public void onBackpressed(){
        if ((webView.canGoBack())){
            webView.goBack();
        }
        else{
            super.onBackPressed();
        }
    }
    }
