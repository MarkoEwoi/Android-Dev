package com.example.checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //declaration
CheckBox pizza,coffee,burger;
Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //getting instances for checkbox and button
        pizza=(CheckBox) findViewById(R.id.checkBox);

        coffee=(CheckBox) findViewById(R.id.checkBox2);

        burger=(CheckBox) findViewById(R.id.checkBox3);

        button=(Button) findViewById(R.id.button);
        //
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int totalamount=0;
                StringBuilder result=new StringBuilder();
                result.append("Selected Item:");
                if (pizza.isChecked()) {

                result.append("\n PIZZA 100Rs");
                totalamount+=100;
                }
                if(coffee.isChecked()){
                    result.append("\n Coffee 50Rs");
                    totalamount+=50;
                }
                if(burger.isChecked()){
                    result.append("\n Burger 50Rs");
                    totalamount+=120;
                }
                result.append("\n Total:"+totalamount+"Rs");
                //Displaying a toast
                Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();

            }

        });
    }
}